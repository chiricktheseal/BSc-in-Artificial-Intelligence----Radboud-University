//package factory;

public class Visitor implements ProductVisitor {
    @Override
    public void visit (Chair chair){
        if (chair.getMaterial().equals("wooden")){
            chair.multiplyPrice(0.85);
        }
        else if (chair.getMaterial().equals("metal")){
            chair.multiplyPrice(1.12);
        }
    }

    @Override
    public void visit (Fridge fridge){
        if (fridge.getBrand().equals("Samsung")){
            fridge.multiplyPrice(0.95);
        }
    }

    @Override
    public void visit (Tv tv){
        if (tv.getConnectorCount("DP") > 1){
            tv.multiplyPrice(0.7);
        }
    }

}