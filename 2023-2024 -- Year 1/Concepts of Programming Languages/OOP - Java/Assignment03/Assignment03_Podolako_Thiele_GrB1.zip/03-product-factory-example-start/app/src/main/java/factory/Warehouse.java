//package factory;

import java.util.List;
import java.util.ArrayList;

public class Warehouse {
    private String name;
    private List<Product> products;

    public Warehouse(String name, List<Product> products) {
        this.name = name;
        this.products = products;
    }

    public static Warehouse createMyWarehouse() {
        List<Product> products = new ArrayList<>();

        Product chair1 = new Chair(50, "wooden");
        Product chair2 = new Chair(100, "metal");
        
        Tv.Builder builder = new Tv.Builder(1920, 1080);
        builder.price(300).brand("LG").model("L27LCD+").bitsPerPixel(24).refreshRate(60).displayTechnology("LCD")
        .addConnector("HDMI").addConnector("HDMI").addConnector("DP").voltage(240).current(0.1);

        Product tv1 = builder.build();
        Product tv2 = builder.build();

        Tv.Builder builder2 = new Tv.Builder(1920, 1080);
        builder2.price(500).brand("Sony").model("S33IPS++").bitsPerPixel(24).refreshRate(90).displayTechnology("IPS")
        .addConnector("HDMI").addConnector("HDMI").addConnector("DP").addConnector("DP").voltage(240).current(0.1);
        Product tv3 = builder2.build();

        Product fridge1 = Fridge.createFreezer("Bosch", 60, 400);
        Product fridge2 = Fridge.createFridge("Samsung", 100, 600);


        products.add(chair1);
        products.add(chair2);
        products.add(tv1);
        products.add(tv2);
        products.add(tv3);
        products.add(fridge1);
        products.add(fridge2);

        return new Warehouse("My warehouse", products);
    }

    public void procedure1() {
        for (int i = 0; i < products.size(); i++){
            if (products.get(i) instanceof Tv){
                if (((Tv)products.get(i)).getDisplayTechnology() == "LCD"){
                    ((Tv)products.get(i)).multiplyPrice(0.9);
                }
                else{}
            }
            else if (products.get(i) instanceof Fridge) {
                if (((Fridge)products.get(i)).hasFreezer() == true){
                    ((Fridge)products.get(i)).multiplyPrice(1.2);
                }
            }

            else {}
        }
    }

    public void procedure2() {
        Visitor visitor = new Visitor();
        for (Product product : products){
            product.accept(visitor);
        }
    }

    @Override
    public String toString() {
        String output = "";
        for (int i = 0; i < this.products.size(); i++){
            output += String.format("%d:      %s \n", i, products.get(i));
        }

        return output;
    }
}
