//package factory;
import java.util.ArrayList;
import java.util.List;

public class Tv implements Product, EnergyConsumer, Display{
    // required fields
    private int horizontalResolution, verticalResolution;

    // optional fields
    private double price, voltage, current;
    private int refreshRate, bitsPerPixel;
    private String brand, model, displayTechnology;
    private List<String> connectors;

    private Tv (Builder builder){
        price = builder.price;
        voltage = builder.voltage;
        current = builder.current;
        horizontalResolution = builder.horizontalResolution;
        verticalResolution = builder.verticalResolution;
        refreshRate = builder.refreshRate;
        bitsPerPixel = builder.bitsPerPixel;
        brand = builder.brand;
        model = builder.model;
        displayTechnology = builder.displayTechnology;
        connectors = builder.connectors;
    }

    public static class Builder {
        // required fields
        private int horizontalResolution, verticalResolution;

        // optional fields
        private double price = 0, voltage = 0, current = 0;
        private int refreshRate = 0, bitsPerPixel = 0;
        private String brand = "", model = "", displayTechnology = "";
        private List<String> connectors = new ArrayList<String>();

        public Builder (int horizontalResolution, int verticalResolution){
            this.horizontalResolution = horizontalResolution;
            this.verticalResolution = verticalResolution;
        }

        Builder price(double price){
            this.price = price;
            return this;
        }

        Builder voltage(double voltage){
            this.voltage = voltage;
            return this;
        }

        Builder current(double current){
            this.current = current;
            return this;
        }

        Builder refreshRate(int refreshRate){
            this.refreshRate = refreshRate;
            return this;
        }

        Builder bitsPerPixel(int bitsPerPixel){
            this.bitsPerPixel = bitsPerPixel;
            return this;
        }

        Builder brand(String brand){
            this.brand = brand;
            return this;
        }

        Builder model(String model){
            this.model = model;
            return this;
        }

        Builder displayTechnology(String displayTechnology){
            this.displayTechnology = displayTechnology;
            return this;
        }

        Builder addConnector(String connector){
            this.connectors.add(connector);
            return this;
        }

        Tv build(){
            return new Tv(this);
        }

    }

    @Override
    public double getPrice(){
        return this.price;
    }

    @Override
    public void setPrice(double newPrice){
        this.price = newPrice;
    }

    @Override
    public double getVoltage(){
        return this.voltage;
    }

    @Override
    public double getCurrent(){
        return this.current;
    }

    @Override
    public double getYearlyEnergyUsage(){
        double energy = getVoltage() * getCurrent() * 365 * 1/1000;
        return energy;
    }

    @Override
    public int getHorizontalResolution (){
        return this.horizontalResolution;
    }

    @Override
    public int getVerticalResolution (){
        return this.verticalResolution;
    }

    @Override
    public int getRefreshRate (){
        return this.refreshRate;
    }

    @Override
    public int getBitsPerPixel (){
        return this.bitsPerPixel;
    }

    @Override
    public String getBrand (){
        return this.brand;
    }

    @Override
    public String getModel (){
        return this.model;
    }

    @Override
    public String getDisplayTechnology (){
        return this.displayTechnology;
    }

    @Override
    public int getConnectorCount(String type){
        int counter = 0;
        for (int i = 0; i < this.connectors.size(); i++){
            if (this.connectors.get(i).equals(type)){
                counter += 1;
            }
        }
        return counter;
    }

    @Override
    public void accept(ProductVisitor visitor){
        visitor.visit(this);
    }

    public String toString(){
        String connectorList = connectors.toString();
        double energy = getYearlyEnergyUsage();
        return String.format("$%-6.2f %s %s, %dx%dx%d@%dhz %s display %s %.0fV %.2fA (%.2fkWh)", 
        price, brand, model, horizontalResolution, verticalResolution, bitsPerPixel, refreshRate, 
        displayTechnology, connectorList, voltage, current, energy);
    }


}