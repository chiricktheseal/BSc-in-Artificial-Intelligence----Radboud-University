//package factory;

public interface EnergyConsumer {
    double getVoltage();
    double getCurrent();
    default double getYearlyEnergyUsage(){
        double energy = getVoltage() * getCurrent() * 24 * 365 * 1/1000;
        return energy;
    }
}