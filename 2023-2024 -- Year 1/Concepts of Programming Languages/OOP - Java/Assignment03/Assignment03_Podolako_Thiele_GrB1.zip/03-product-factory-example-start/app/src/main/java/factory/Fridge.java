//package factory;

public class Fridge implements Product, EnergyConsumer {
    private double price;
    private double voltage;
    private double current;
    private boolean hasFreezer;
    private int volume;
    private String brand;

    private Fridge(String brand, int volume, double price){
        this.brand = brand;
        this.volume = volume;
        this.price = price;
    }

    public static Fridge createFreezer(String brand, int volume, double price){
        Fridge freezer = new Fridge (brand, volume, price);
        freezer.voltage = 240;
        freezer.current = 2;
        freezer.hasFreezer = true;
        return freezer;
    }

    public static Fridge createFridge(String brand, int volume, double price){
        Fridge fridge = new Fridge (brand, volume, price);
        fridge.voltage = 240;
        fridge.current = 2;
        fridge.hasFreezer = false;
        return fridge;
    }

    @Override
    public double getPrice(){
        return this.price;
    }

    @Override
    public void setPrice(double newPrice){
        this.price = newPrice;
    }

    @Override
    public double getVoltage(){
        return this.voltage;
    }

    @Override
    public double getCurrent(){
        return this.current;
    }

    @Override
    public void accept(ProductVisitor visitor){
        visitor.visit(this);
    }

    public boolean hasFreezer(){
        return this.hasFreezer;
    }

    public String getBrand(){
        return this.brand;
    }

    public String toString(){
        String output = "";
        double energy = getYearlyEnergyUsage();
        if (hasFreezer){
            output += output.format("$%-6.2f %s %dl fridge with freezer %.0fV %.2fA (%.2fkWh)", price, brand, volume, voltage, current, energy);
        }
        else {
            output += output.format("$%-6.2f %s %dl fridge without freezer %.0fV %.2fA (%.2fkWh)", price, brand, volume, voltage, current, energy);
        }
        return output;
    }

}