package geometric;
import java.util.Scanner;

public class IO {
    private Scanner scanner;

    // constructor that creates a new scanner object to read user input
    public IO() {
        scanner = new Scanner(System.in);
    }

    // Method to show the possible actions the user can take
    public void welcomeInstructions(){
        String instructions = "";
        instructions += "\n\nEnter a command to perform an action:" +
                        "\n  1. quit ---> to exit " +
			            "\n  2. show ---> displays information about each object" +
			            "\n  3. circle x y r ---> creates a Circle with the center at (x, y) and radius r. Example: circle 1 2.5 3.0" +
			            "\n  4. rectangle x y w h ---> creates a Rectangle with lower left corner at (x, y), width w, and height h. Example: rectangle 1 2.5 3.0 2.2" +
			            "\n  5. move index dx dy ---> moves the object at index. Example: move 0 2.5 1.0" +
			            "\n  6. remove index ---> removes the object at index. Example: remove 1" +
			            "\n  7. filter x/y/a n ---> filters objects based on specified leftMost (x), bottomMost (y) or area (a) below a threshold n. Example:  filter x 4.0" +
			            "\n  8. sort x/y ---> sorts objects in the array based on leftMost (x), bottomMost (y) or area (when no argument is given). Example: sort x" + 
                        "\n\n";
        System.out.println(instructions);
    }

    // Method to read the user input
    public String getUserInput(){
        String input = scanner.nextLine().trim();
        return input;
    }

    // Method that prints the starting greeting
    public void greeting(){
        System.out.println("Welcome to the Geometric Shapes Program!");
    }

    // Method that prints Invalid Input to the console
    public void printInvalidInput(){
        System.out.println("\nThis input is invalid.");
    }

    // Method that formats the Geometric characteristics of Geometric objects and prints an overview
    public void showObjects(Geometric[] shapes){

        System.out.println("\n");
        for (int i = 0; i < shapes.length; i++) {
            Geometric object = shapes[i];
            String showObject = String.format("Object %2d: ", i);
            // Checking if the current array slot contains an object
            if (object == null) {
                showObject += "Null"; // Appending "Null" to the display string if the slot is empty
            } else {
                showObject += object.toString(); // Appending the string representation of the object if it is not null
            }
            System.out.println(showObject);  // Printing the formatted string to the console
        }
        System.out.println("\n");
    }

    // Method that prints a goodbye message
    public void goodbye(){
        System.out.println("\nGoodbye!\n");
    }


}