package geometric;

// Class implementing GeometricPredicate to filter shapes based on area
public class FilterAreaCriterion implements GeometricPredicate{
    private double threshold; // The threshold area for filtering

    // Constructor to initialize the FilterAreaCriterion with a given threshold
    public FilterAreaCriterion(double n) {
        this.threshold = n;
    }

    // Implementation of the predicate method from GeometricPredicate interface
    // Returns true if the shape's area is less than the threshold, indicating it should be filtered
    @Override
    public boolean predicate(Geometric shape){
        // Calculating the area of the given shape
        double area = shape.area();  
        
        // Checking if the area is less than the threshold
        if (area < threshold) {
            return true; // Shape should be filtered
        }
        else {
            return false; // Shape should not be filtered
        }
    }
}