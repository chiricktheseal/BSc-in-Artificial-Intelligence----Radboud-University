package geometric;

// Interface representing a geometric shape with common properties and actions
public interface Geometric {
    // Methods to get the left, right, bottom, and top borders of the geometric shape
    public double leftBorder();
    public double rightBorder();
    public double bottomBorder();
    public double topBorder();
    // Method to calculate the area of the geometric shape
    public double area();
    // Method to move the geometric shape by a specified amount in the x and y directions
    public void moveObject(double dx, double dy);
}