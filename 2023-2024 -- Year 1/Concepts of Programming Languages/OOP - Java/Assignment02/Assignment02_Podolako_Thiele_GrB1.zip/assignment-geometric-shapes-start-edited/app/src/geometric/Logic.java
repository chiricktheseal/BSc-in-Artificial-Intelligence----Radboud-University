package geometric;
import java.util.Arrays;

public class Logic {

    // constructor
    public Logic() {}

    // Method that starts the program and calls other methods when necessary
    public void start(){
        // Array to store Geometric objects
		Geometric[] shapes = new Geometric[10];

        // Object of class IO to handle input and output
        IO io = new IO();

        while (true){
			// Reading user input
			String userChoice = io.getUserInput();

			// Exiting the program
			if (userChoice.equals("quit")){
				io.goodbye();
                break;
			}

			// Displaying information about each object in the array
			else if (userChoice.equals("show")){
				io.showObjects(shapes);
				
			}
			// Handling more complex user commands
			else{
                // Splitting user input into an array of strings
				String[] input = userChoice.split(" ");

				// Creating a Circle object and adding it to the shapes array
				if (input[0].equals("circle")){
					addCircle(input, shapes);
				}
				// Creating a Rectangle object and adding it to the shapes array
				else if (input[0].equals("rectangle")){
					addRectangle(input, shapes);
				}

				// Moving an object to the specified coordinates
				else if (input[0].equals("move")){
					int index = Integer.parseInt(input[1]);
					double dx = Double.parseDouble(input[2]);
					double dy = Double.parseDouble(input[3]);
					shapes[index].moveObject(dx, dy);
				}

				// Removing an object from the array
				else if (input[0].equals("remove")){
					int index = Integer.parseInt(input[1]);
					shapes[index] = null;
				}

				// Filtering objects based on specified criteria
				else if (input[0].equals("filter")){
					double n = Double.parseDouble(input[2]);
					// Creating a FilterLeftCriterion and applying it to filter objects
					if (input[1].equals("x")){
						FilterLeftCriterion flc = new FilterLeftCriterion(n);
						filterObjects(flc, shapes);
					}
					// Creating a FilterBottomCriterion and applying it to filter objects
					else if (input[1].equals("y")){
						FilterBottomCriterion fbc = new FilterBottomCriterion(n);
						filterObjects(fbc, shapes);
					}
					// Creating a FilterAreaCriterion and applying it to filter objects
					else if (input[1].equals("a")){
						FilterAreaCriterion fac = new FilterAreaCriterion(n);
						filterObjects(fac, shapes);
					}
					else {
						io.printInvalidInput();
					}
				}

				// Sorting objects in the array based on specified criteri
				else if (input[0].equals("sort")){
					// Sorting by area if no specific criterion is provide
					if (input.length < 2){
						SortByArea sa = new SortByArea();
						Arrays.sort(shapes, sa);
					}
                    // Sorting by leftmost x-coordinate
                    else if (input[1].equals("x")){
                        SortByLeftMost slm = new SortByLeftMost();
                        Arrays.sort(shapes, slm);
                    }
                    // Sorting by bottommost y-coordinate
                    else if (input[1].equals("y")){
                        SortByBottomMost sbm = new SortByBottomMost();
                        Arrays.sort(shapes, sbm);
                    }
                    else {
                        io.printInvalidInput();
                    }	
				}
				else{
					io.printInvalidInput();
				}
			}
            // showing an overview of all objects after each action
            io.showObjects(shapes);
		}
    }

    // Method that adds a circle to the array
    public void addCircle(String[] input, Geometric[] shapes){
        // converting user input into type double
        double x = Double.parseDouble(input[1]);
        double y = Double.parseDouble(input[2]);
        double r = Double.parseDouble(input[3]);

        // creating a new object of type Circle with the given user input and adding it to the array
        Circle c = new Circle(x, y, r);
        addObjectAtFreeIndex(c, shapes);

    }

    // Method that adds a Rectangle to the array
    public void addRectangle(String[] input, Geometric[] shapes){
        // converting user input into type double
        double x = Double.parseDouble(input[1]);
        double y = Double.parseDouble(input[2]);
        double w = Double.parseDouble(input[3]);
        double h = Double.parseDouble(input[4]);

        // creating a new object of type Rectangle with the given user input and adding it to the array
        Rectangle r = new Rectangle(x, y, w, h);
        addObjectAtFreeIndex(r, shapes);
    }

    // Method that add an object of type Geometric at a free index in the array
    public void addObjectAtFreeIndex(Geometric obj, Geometric[] shapes){
        // Finding the first null slot in the array and assigning the Rectangle object
        for (int i = 0; i < shapes.length; i++){
            if (shapes[i] == null){
                shapes[i] = obj;
                break;
            }
        }
    }

    // Method that removes objects from the array
    public void filterObjects(GeometricPredicate gp, Geometric[] shapes){
        for (int i = 0; i < shapes.length; i++){
            if ((shapes[i]!=null) && (gp.predicate(shapes[i]))){
                shapes[i] = null;
            }
        }
    }

    
}