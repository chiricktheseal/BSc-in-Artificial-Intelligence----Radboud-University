package geometric;

// Rectangle class implementing the Geometric interface
public class Rectangle implements Geometric{
    // Private instance variables for the Rectangle
    private double xLowLeft;    // x coordinate of the lower left corner
    private double yLowLeft;    // y coordinate of the lower left corner
    private double height;
    private double width;

    // Constructor to initialize the Rectangle with given coordinates, width, and height
    public Rectangle(double x, double y, double w, double h){
        this.xLowLeft = x;
        this.yLowLeft = y;
        this.width = w;
        this.height = h;
    }
    
    // Method to get the left border of the Rectangle
    @Override
    public double leftBorder(){
        double left = this.xLowLeft; // Returning the x-coordinate of the lower left corner
        return left;
    }

    // Method to get the right border of the Rectangle
    @Override
    public double rightBorder(){
        double right = this.xLowLeft + this.width; // Adding width to the x-coordinate of the lower left corner to get the right border
        return right;
    }

    // Method to get the bottom border of the Rectangle
    @Override
    public double bottomBorder(){
        double bottom = this.yLowLeft; // Returning the y-coordinate of the lower left corner
        return bottom;
    }

    // Method to get the top border of the Rectangle
    @Override
    public double topBorder(){
        double top = this.yLowLeft + this.height;  // Adding height to the y-coordinate of the lower left corner to get the top border
        return top;
    }

    // Method to calculate the area of the Rectangle
    @Override
    public double area(){
        double area = this.width * this.height; // Multiplying width by height to get the area
        return area;
    }

    // Method to move the Rectangle by a specified amount in the x and y directions
    @Override
    public void moveObject(double dx, double dy){
        // Updating the x and y coordinates based on the provided values
        this.xLowLeft = this.xLowLeft + dx;
        this.yLowLeft = this.yLowLeft + dy;
    }

    // Method to represent the Rectangle as a formatted string
    public String toString(){
        // Creating a formatted string with information about the Rectangle's lower left corner, height, and width
        String result = String.format("Rectangle :  Lower Left Corner at (%.2f, %.2f)   Height: %.2f   Width: %.2f", xLowLeft, yLowLeft, height, width);
        return result;
    }
}