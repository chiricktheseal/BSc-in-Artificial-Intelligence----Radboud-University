package geometric;
import java.lang.Math;

// Circle class implementing the Geometric interface
public class Circle implements Geometric{
    // Private instance variables for the Circle
    private double radius;
    private double xValue;  // x value of the centre of the Circle
    private double yValue;  // y value of the centre of the Circle

    // Constructor to initialize the Circle with given coordinates and radius
    public Circle(double x, double y, double r){
        this.xValue = x;
        this.yValue = y;
        this.radius = r;
    }
    
    // Method to get the left border of the Circle
    @Override
    public double leftBorder(){
        double left = this.xValue - 1;  // Subtracting 1 from x-coordinate to get the left border
        return left;
    }

    // Method to get the right border of the Circle
    @Override
    public double rightBorder(){
        double right = this.xValue + 1;   // Adding 1 to x-coordinate to get the right border
        return right;
    }

    // Method to get the bottom border of the Circle
    @Override
    public double bottomBorder(){
        double bottom = this.yValue - 1;  // Subtracting 1 from y-coordinate to get the bottom border
        return bottom;
    }

    // Method to get the top border of the Circle
    @Override
    public double topBorder(){
        double top = this.yValue + 1;   // Adding 1 to y-coordinate to get the top border
        return top;
    }

    // Method to calculate the area of the Circle
    @Override
    public double area(){
        double area = Math.PI * this.radius * this.radius; // Using the formula for the area of a circle: Pi * radius^2
        return area;
    }
    
    // Method to move the Circle by a specified amount in the x and y directions
    @Override
    public void moveObject(double dx, double dy){
        // Updating the x and y coordinates based on the provided values
        this.xValue = this.xValue + dx;
        this.yValue = this.yValue + dy;
    }

    // Method to represent the Circle as a formatted string
    public String toString(){
        // The formatted string representation for the Circle, indicating the center coordinates with two decimal places.
        String result = String.format("Circle    :  Center at (%.2f, %.2f)              Radius: %.2f", xValue, yValue, radius);
        return result;
    }

}