package geometric;

// Class implementing GeometricPredicate to filter shapes based on the leftmost x-coordinate
public class FilterLeftCriterion implements GeometricPredicate{
    private double threshold;  // The threshold leftmost x-coordinate for filtering

    // Constructor to initialize the FilterLeftCriterion with a given threshold
    public FilterLeftCriterion(double n) {
        this.threshold = n;
    }

    // Implementation of the predicate method from GeometricPredicate interface
    // Returns true if the shape's leftmost x-coordinate is less than the threshold, indicating it should be filtered
    @Override
    public boolean predicate(Geometric shape){
        // Retrieving the leftmost x-coordinate of the given shape
        double leftMost = shape.leftBorder();

        // Checking if the leftmost x-coordinate is less than the threshold
        if (leftMost < threshold) {
            return true;  // Shape should be filtered
        }
        else {
            return false;  // Shape should not be filtered
        }
    }
}