package geometric;

import java.util.Comparator;

// Comparator class for sorting geometric shapes by their bottommost y-coordinate
public class SortByBottomMost implements Comparator<Geometric> {

    // Implementation of the compare method from Comparator interface
    // Compares two geometric shapes based on their bottommost y-coordinates
    @Override
    public int compare(Geometric o1, Geometric o2){
        // Handling cases where one or both shapes are null
        if ((o1 == null) && (o2 == null)){
            return 0; // Both shapes are considered equa
        }
        else if (o1 == null){ // Null is considered greater than a non-null shape
            return 1;
        }
        else if (o2 == null){ // Null is considered less than a non-null shape
            return -1;
        }
        else {
            // Comparing shapes based on their bottommost y-coordinates
            if (o1.bottomBorder() < o2.bottomBorder()){
                return -1; // o1 is considered bottommost
            }
    
            else if (o1.bottomBorder() > o2.bottomBorder()){
                return 1; // o1 is considered topmost
            }
            else {
                return 0; // Both shapes have equal bottommost y-coordinates
            }
        }
        
    }
}