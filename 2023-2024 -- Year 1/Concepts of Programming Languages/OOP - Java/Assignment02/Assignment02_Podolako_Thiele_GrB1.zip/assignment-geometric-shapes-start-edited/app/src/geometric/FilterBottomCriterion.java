package geometric;

// Class implementing GeometricPredicate to filter shapes based on the bottommost y-coordinate
public class FilterBottomCriterion implements GeometricPredicate{
    private double threshold;  // The threshold bottommost y-coordinate for filtering

    // Constructor to initialize the FilterBottomCriterion with a given threshold
    public FilterBottomCriterion(double n) {
        this.threshold = n;
    }

    // Implementation of the predicate method from GeometricPredicate interface
    // Returns true if the shape's bottommost y-coordinate is less than the threshold, indicating it should be filtered
    @Override
    public boolean predicate(Geometric shape){
        // Retrieving the bottommost y-coordinate of the given shape
        double bottomMost = shape.bottomBorder();

        // Checking if the bottommost y-coordinate is less than the threshold
        if (bottomMost < threshold) {
            return true;  // Shape should be filtered
        }
        else {
            return false;  // Shape should not be filtered
        }
    }
}