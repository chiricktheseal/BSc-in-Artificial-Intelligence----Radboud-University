package geometric;

import java.util.Arrays;

public class Main {

	public static void main(String[] args) {

		// creating an object of class IO to print a welcome message and the program instructions
		IO io = new IO();
		io.greeting();
		io.welcomeInstructions();
		
		// creating an object of class Logic to start the program
		Logic logic = new Logic();
		logic.start();
	}

}