package geometric;

import java.util.Comparator;

// Comparator class for sorting geometric shapes by their leftmost x-coordinate
public class SortByLeftMost implements Comparator<Geometric> {

    // Implementation of the compare method from Comparator interface
    // Compares two geometric shapes based on their leftmost x-coordinates
    @Override
    public int compare(Geometric o1, Geometric o2){
        // Handling cases where one or both shapes are null
        if ((o1 == null) && (o2 == null)){
            return 0; // Both shapes are considered equal
        }
        else if (o1 == null){ 
            return 1; // Null is considered greater than a non-null shape
        }
        else if (o2 == null){
            return -1; // Null is considered less than a non-null shape
        }
        // Comparing shapes based on their leftmost x-coordinates
        else {
            if (o1.leftBorder() < o2.leftBorder()){
                return -1; // o1 is considered leftmost
            }
    
            else if (o1.leftBorder() > o2.leftBorder()){
                return 1;  // o1 is considered rightmost
            }
            else {
                return 0; // Both shapes have equal leftmost x-coordinates
            }
        }
        
    }
}