package geometric;

// Interface representing a geometric predicate for evaluating properties of geometric shapes
public interface GeometricPredicate {
    // Method signature for the predicate that takes a Geometric shape as an argument and returns a boolean result
    public boolean predicate(Geometric shape);
}