package geometric;

import java.util.Comparator;

// Comparator class for sorting geometric shapes by their area
public class SortByArea implements Comparator<Geometric> {

    // Implementation of the compare method from Comparator interface
    // Compares two geometric shapes based on their areas
    @Override
    public int compare(Geometric o1, Geometric o2){
        // Handling cases where one or both shapes are null
        if ((o1 == null) && (o2 == null)){
            return 0; // Both shapes are considered equal
        }
        else if (o1 == null){
            return 1; // Null is considered greater than a non-null shape
        }
        else if (o2 == null){
            return -1; // Null is considered less than a non-null shape
        }
        // Comparing shapes based on their areas
        else {
            if (o1.area() < o2.area()){
                return -1; // o1 is considered smaller
            }
    
            else if (o1.area() > o2.area()){
                return 1; // o1 is considered larger
            }
            else {
                return 0; // Both shapes have equal areas
            }
        }
        
    }
}